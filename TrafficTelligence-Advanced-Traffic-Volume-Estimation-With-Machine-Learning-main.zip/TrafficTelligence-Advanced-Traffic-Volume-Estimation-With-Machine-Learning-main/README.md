# TrafficTelligence-Advanced-Traffic-Volume-Estimation-With-Machine-Learning

## model flie link-https://drive.google.com/file/d/1v0VLRrqM5D8_LjFvlKoPhGMIuFOaH-gh/view?usp=sharing4

## Demo Video link-https://youtu.be/mgBQPQHPUOo


